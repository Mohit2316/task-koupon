<?php

// Set your email address
define("EMAIL_ADDRESS", 'you@yourdomain.com');

// Set subject for recived letters
define("EMAIL_SUBJECT", "Subject to your letters");
