<?php
mysql_connect("localhost", "kouponiz_demo", "U478IFbw?pBb") or die ("Oops! Server not connected"); // Connect to the host
mysql_select_db("kouponiz_demo") or die ("Oops! DB not connected"); // select the database
?>