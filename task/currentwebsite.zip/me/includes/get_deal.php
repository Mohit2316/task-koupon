 <!--GET DEAL FUNCTION-->
<div id="get-deal" class="mfp-with-anim mfp-hide mfp-dialog clearfix">
<object data="admin/get_deal.php" width="400" height="400">
<embed src="admin/get_deal.php" width="600" height="400"> </embed> Error: Embedded data could not be displayed. </object>
</div>